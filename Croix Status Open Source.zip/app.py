from flask import Flask, render_template, request, jsonify
import threading
import time
import random
from datetime import datetime
import socket

app = Flask(__name__)

ip_addresses = [
    {"name": "", "ip": ""},
    {"name": "", "ip": ""},
    {"name": "", "ip": ""},
    {"name": "", "ip": ""},
    {"name": "", "ip": ""},
    {"name": "", "ip": ""},
    {"name": "", "ip": ""}
]

announcement_text = "Hope you check all nodes status and uptime here!"

monitoring_interval = 10  # Monitor every 10 seconds
last_ping_statuses = {}
daily_percentages = {}
online_start_times = {}

def is_host_reachable(host, port):
    try:
        # Create a socket connection to the host and port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)  # Adjust the timeout as needed
            s.connect((host, port))
        return True  # If connection is successful, the host is reachable
    except (socket.timeout, ConnectionRefusedError):
        return False  # Connection timed out or refused, indicating the host is not reachable

def monitor_ips():
    global last_ping_statuses
    global online_start_times
    while True:
        for ip in ip_addresses:
            if is_host_reachable(ip["ip"], 22):  # Check if port 80 is reachable (HTTP)
                last_ping_statuses[ip["ip"]] = "Online"
                if ip["ip"] not in online_start_times:
                    online_start_times[ip["ip"]] = datetime.now()
            else:
                last_ping_statuses[ip["ip"]] = "Offline"
                online_start_times.pop(ip["ip"], None)
            # Simulate daily checks with random percentages (for demonstration purposes)
            daily_percentages[ip["ip"]] = random.randint(80, 100)
        time.sleep(monitoring_interval)

def calculate_online_days():
    global online_start_times
    while True:
        current_time = datetime.now()
        for ip, start_time in list(online_start_times.items()):
            online_duration = current_time - start_time
            online_days = online_duration.days
            online_start_times[ip] = online_days
        time.sleep(86400)  # Calculate online days once a day

@app.route('/')
def index():
    return render_template('index.html', ip_addresses=ip_addresses, last_ping_statuses=last_ping_statuses, daily_percentages=daily_percentages, online_days=online_start_times, announcement_text=announcement_text)

@app.route('/ping', methods=['GET'])
def ping():
    ip = request.args.get('ip')
    status = last_ping_statuses.get(ip, "Unknown")
    return jsonify({'status': status})


if __name__ == '__main__':
    monitor_thread = threading.Thread(target=monitor_ips)
    monitor_thread.daemon = True
    monitor_thread.start()

    online_days_thread = threading.Thread(target=calculate_online_days)
    online_days_thread.daemon = True
    online_days_thread.start()
    
    app.run(host='0.0.0.0', port=25571)
